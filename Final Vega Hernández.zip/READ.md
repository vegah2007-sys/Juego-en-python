# Escape del Castillo de Gothel

## 1. Descripcion del proyecto

Este proyecto consiste en un minijuego por turnos desarrollado en Python utilizando Programacion Orientada a Objetos.

El jugador controla a Rapunzel, quien debe escapar de un castillo compuesto por distintas habitaciones conectadas entre si. Durante la partida, el personaje puede encontrar objetos, enfrentarse a enemigos y tomar decisiones que afectan al desarrollo del juego.

Una vez Rapunzel logra salir del castillo, comienza la segunda fase del juego: un bosque representado mediante una matriz donde deberá encontrar a Flynn Rider para escapar definitivamente.

El objetivo principal es derrotar a todos los enemigos (3 en el castillo y 2 en el bosque) y alcanzar la salida.


## 2. Estructura del programa

El programa está organizado en varios modulos que contienen las siguientes clases:

### 2.1 Archivo Personajes.py

**Clase Rapunzel** (personaje principal)

Atributos:
- vida
- ataque
- defensa
- experiencia
- inventario

Metodos principales:
- atacar()
- recibir_golpe()
- utilizar_objeto()
- eliminar_objeto()
- mostrar_estado()
- mostrar_inventario()
- esta_viva()

**Clase Guardia** (enemigos)

Atributos:
- nombre
- vida
- ataque

Metodos:
- atacar()
- recibir_golpe()
- mostrar_estado()
- esta_vivo()


### 2.2 Archivo Item.py

**Clase Item** (objetos recogibles)

Atributos:
- nombre
- tipo (curacion o ataque)
- valor
- descripcion

Metodos:
- utilizar()
- mostrar()


### 2.3 Archivo Inventario.py

**Clase Inventario** (gestiona los objetos de Rapunzel)

Funcionalidades:
- anadir objetos
- eliminar objetos
- consultar objetos
- utilizar objetos
- mostrar inventario
- comprobar si un objeto ya se tiene 


## 3. Metodos dunder utilizados

- __lt__ (en Rapunzel): compara si Rapunzel tiene menos vida que el enemigo
- __gt__ (en Rapunzel): compara si Rapunzel tiene mas vida que el enemigo
- __iadd__ (en Inventario): anade un objeto al inventario usando el operador +=


## 4. Funcionamiento del juego

### Fase 1: El castillo

1. El jugador reparte 20 puntos entre las habilidades de Rapunzel (vida, ataque, defensa)
2. Rapunzel comienza en la celda
3. El jugador puede desplazarse entre habitaciones conectadas (escribiendo el numero de la puerta)
4. En algunas habitaciones se encuentran:
   - objetos (se anaden automaticamente al inventario)
   - enemigos (se inicia un combate por turnos)
5. Durante el combate, el jugador puede:
   - atacar
   - usar objetos
   - consultar o eliminar objetos
   - huir
6. Al derrotar a los 3 enemigos (Soldado Real, Guardia Mayor y Gothel), la salida se desbloquea

### Fase 2: El bosque (ampliacion con matriz)

Una vez Rapunzel sale del castillo, comienza la segunda fase:

1. El juego cambia a un mapa representado mediante una matriz de 6x6
2. Los elementos de la matriz son:
   - 0 = camino libre
   - 1 = Rapunzel (posicion inicial)
   - 2 = arbol (obstaculo, no se puede pasar)
   - 3 = enemigo
   - 4 = Flynn Rider (objetivo final)
3. El jugador se mueve con las teclas W, A, S, D
4. Solo se ve la posicion de Rapunzel (R) y los arboles (#). El resto es niebla (?)
5. Al pisar un enemigo (3), se derrota automaticamente (combate simplificado)
6. Al pisar a Flynn Rider (4), el juego termina con victoria

### Condiciones de fin del juego

- Derrota: Rapunzel pierde toda su vida en un combate del castillo
- Victoria: Rapunzel derrota a Gothel, sale del castillo, cruza el bosque y encuentra a Flynn Rider


## 5. Mapa del bosque (matriz)

La matriz utilizada en la fase 2 es la siguiente:

mapa = [
    [2, 2, 2, 2, 2, 2],
    [2, 1, 0, 3, 0, 2],
    [2, 0, 2, 0, 0, 2],
    [2, 0, 0, 2, 3, 2],
    [2, 0, 4, 0, 0, 2],
    [2, 2, 2, 2, 2, 2]
]

Visualmente se representa asi :

Fila 0: # # # # # #
Fila 1: # R . ? . #
Fila 2: # . # . . #
Fila 3: # . . # ? #
Fila 4: # . F . . #
Fila 5: # # # # # #

Leyenda:
- # = arbol (obstaculo)
- R = Rapunzel
- ? = enemigo (no visible hasta pisarlo)
- F = Flynn Rider
- . = camino libre


## 6. Enemigos y objetos

### Enemigos del castillo

- Soldado Real: vida 8, ataque 3, ubicado en la Armeria
- Guardia Mayor: vida 12, ataque 4, ubicado en la Torre
- Gothel: vida 18, ataque 6, ubicado en el Salon

### Enemigos del bosque

- Enemigo 1: vida 8, ataque 4, ubicado en posicion (1,3) de la matriz
- Enemigo 2: vida 10, ataque 4, ubicado en posicion (3,4) de la matriz

### Objetos del castillo

- Pocion Magica: tipo curacion, efecto +8 vida, ubicado en la Biblioteca
- Sarten de Oro: tipo ataque, efecto +3 ataque, ubicado en la Cocina
- Vendas: tipo curacion, efecto +5 vida, ubicado en el Jardin


## 7. Ampliaciones realizadas

Respecto al proyecto base, se han implementado las siguientes ampliaciones:

1. Eliminacion de la magia: Se simplificaron las habilidades de Rapunzel a 3 (vida, ataque, defensa) y los puntos a repartir se redujeron a 20.

2. Matriz del bosque: Se añadió una segunda fase al juego donde Rapunzel debe cruzar un bosque representado mediante una matriz de 6x6, con obstaculos, enemigos y un objetivo final (Flynn Rider).

3. Sistema de niebla de guerra: En el bosque, el jugador solo ve su posicion y los obstaculos. El resto del mapa permanece oculto hasta que se explora.

4. Movimiento por coordenadas: En la fase 2, el movimiento se realiza con teclas W, A, S, D en lugar de seleccionar puertas con numeros.

