from Personajes import Rapunzel, Guardia
from Item import Item


# ==============================================
# FUNCIONES DEL JUEGO 
# ==============================================

def mostrar_habitacion(nombre, habitacion):
    print(f"\n  [ {nombre.upper()} ]")
    print(f"  {habitacion['descripción']}")
    if len(habitacion["puertas"]) == 0:
        print("  Es un callejón sin salida. Escribe 1 para retroceder.")
    else:
        print("  Puertas disponibles:")
        for i in range(len(habitacion["puertas"])):
            print(f"    {i + 1}. {habitacion['puertas'][i]}")


def combate(rapunzel, guardia):
    print(f"\n  Rapunzel se encuentra con {guardia.nombre}. Hay que luchar.\n")

    guardia_eliminado = False
    bucle_combate = True

    while bucle_combate == True:
        rapunzel.mostrar_estado()
        guardia.mostrar_estado()

        if rapunzel < guardia:
            print("  Rapunzel tiene menos vida que el guardia. Cuidado!")
        elif rapunzel > guardia:
            print("  Rapunzel tiene mas vida que el guardia. Buena posicion.")

        print()
        print("  Que hace Rapunzel?")
        print("  1 - Atacar")
        print("  2 - Usar objeto")
        print("  3 - Consultar / Eliminar objeto")
        print("  4 - Huir")
        accion = input("  Acción: ")

        if accion == "1":
            rapunzel.atacar(guardia)

            if guardia.esta_vivo() == False:
                print(f"\n  {guardia.nombre} ha caído!")
                rapunzel.experiencia += 10
                print(f"  Rapunzel gana 10 de experiencia. Total: {rapunzel.experiencia}\n")
                guardia_eliminado = True
                bucle_combate = False
            else:
                guardia.atacar(rapunzel)
                if rapunzel.esta_viva() == False:
                    print("\n  Rapunzel ha sido capturada. Fin de la partida.\n")
                    bucle_combate = False

        elif accion == "2":
            rapunzel.mostrar_inventario()
            if len(rapunzel.inventario.objetos) > 0:
                try:
                    indice = int(input("  ¿Qué objeto usas? (número): "))
                    rapunzel.utilizar_objeto(indice)
                except ValueError:
                    print("  Número no valido.")

                if guardia.esta_vivo():
                    print("  El guardia aprovecha para atacar!")
                    guardia.atacar(rapunzel)
                    if rapunzel.esta_viva() == False:
                        print("\n  Rapunzel ha sido capturada. Fin de la partida.\n")
                        bucle_combate = False

        elif accion == "3":
            rapunzel.mostrar_inventario()
            if len(rapunzel.inventario.objetos) > 0:
                try:
                    indice = int(input("  ¡Qué objeto consultas? (número): "))
                    objeto = rapunzel.inventario.consultar(indice)
                    if objeto != "":
                        print("  Has seleccionado este objeto:")
                        objeto.mostrar()
                        confirmar = input("  Eliminar este objeto del inventario? (s/n): ")
                        if confirmar == "s":
                            rapunzel.eliminar_objeto(indice)
                except ValueError:
                    print("  Ese número no es válido.")

        elif accion == "4":
            print("  Rapunzel huye. El guardia sigue en su habitación.")
            bucle_combate = False

        else:
            print("  Opción no válida. Elige un número del 1 al 4 por favor.")

    rapunzel_viva = rapunzel.esta_viva()
    return rapunzel_viva, guardia_eliminado


# ==============================================
# FASE 2: MATRIZ DEL BOSQUE (ampliación)
# ==============================================

def bosque_matriz(rapunzel):
    print("")
    print("=" * 40)
    print("   RAPUNZEL ENTRA EN EL BOSQUE")
    print("=" * 40)
    print("Debe encontrar a Flynn Rider para escapar.")
    print("Muevete con W A S D")
    print("Los # son arboles (no se puede pasar)")
    print("Los ? son enemigos")
    print("F es Flynn (tu objetivo)")
    print("")

    mapa = [
        [2, 2, 2, 2, 2, 2],
        [2, 1, 0, 3, 0, 2],
        [2, 0, 2, 0, 0, 2],
        [2, 0, 0, 2, 3, 2],
        [2, 0, 4, 0, 0, 2],
        [2, 2, 2, 2, 2, 2]
    ]

    fila = 1
    col = 1
    enemigos_derrotados = 0
    jugando = True

    while jugando:
        for i in range(6):
            linea = ""
            for j in range(6):
                if i == fila and j == col:
                    linea = linea + " R  "
                elif mapa[i][j] == 2:
                    linea = linea + " #  "
                elif mapa[i][j] == 3:
                    linea = linea + " ?  "
                elif mapa[i][j] == 4:
                    linea = linea + " ?  "
                else:
                    linea = linea + " .  "
            print(linea)
        print("Enemigos derrotados:", enemigos_derrotados)

        movimiento = input("Movimiento (w/a/s/d): ")

        nueva_fila = fila
        nueva_col = col

        if movimiento == "w":
            nueva_fila = fila - 1
        elif movimiento == "s":
            nueva_fila = fila + 1
        elif movimiento == "a":
            nueva_col = col - 1
        elif movimiento == "d":
            nueva_col = col + 1
        else:
            print("Tecla no valida")


        if nueva_fila >= 0 and nueva_fila < 6 and nueva_col >= 0 and nueva_col < 6:
            if mapa[nueva_fila][nueva_col] == 2:
                print("Hay un arbol, no puedes pasar")
            else:
                mapa[fila][col] = 0
                fila = nueva_fila
                col = nueva_col

                if mapa[fila][col] == 3:
                    print("")
                    print("¡Un enemigo te ataca!")
                    print("Lo derrotas sin problemas.")
                    enemigos_derrotados = enemigos_derrotados + 1
                    mapa[fila][col] = 1
                    print("Enemigo derrotado! Llevas", enemigos_derrotados)

                elif mapa[fila][col] == 4:
                    print("")
                    print("=" * 40)
                    print("  ¡ENCONTRASTE A FLYNN RIDER!")
                    print("  Escapásis juntos del bosque.")
                    print("  ¡RAPUNZEL ES LIBRE!")
                    print("=" * 40)
                    jugando = False

                else:
                    mapa[fila][col] = 1
        else:
            print("No puedes salir del bosque")

    return True


# ==============================================
# JUEGO PRINCIPAL
# ==============================================

print("El castillo de Gothel lleva años siendo la prisión de Rapunzel.")
print("Muros de piedra, guardias en cada esquina y una sola salida.\n")
print("Pero esta noche todo cambia.")
print("Rapunzel ha decidido escapar.\n")
print("El castillo esta lleno de habitaciones conectadas entre sí.")
print("Algunas tienen guardias. Otras esconden objetos.")
print("Y algunas no llevan a ninguna parte.\n")
print("Solo hay una salida. Y está muy lejos de aquí.\n")
print("Serás tu quien guie a Rapunzel.")
print("Deberás hacer todo lo posible para que Rapunzel consiga escapar.")

puntos = 20
print("Tienes 20 puntos para repartir entre las 3 habilidades de Rapunzel:")
print("  - vida    : aguanta mas golpes antes de caer")
print("  - ataque  : hace mas daño a los guardias")
print("  - defensa : reduce el daño que recibe Rapunzel")
print("Se consciente de como los repartes. Determinará si Rapunzel escapa o es capturada.\n")

bucle_habilidades = True
while bucle_habilidades == True:
    try:
        vida = int(input("Puntos en vida: "))
        ataque = int(input("Puntos en ataque: "))
        defensa = int(input("Puntos en defensa: "))

        if vida + ataque + defensa > puntos:
            print("\n  Has superado el límite de puntos. Inténtalo de nuevo por favor.\n")
        elif vida < 1:
            print("\n  Todas las habilidades necesitan mínimo 1 punto.\n")
        elif ataque < 1:
            print("\n  Todas las habilidades necesitan mínimo 1 punto.\n")
        elif defensa < 1:
            print("\n  Todas las habilidades necesitan mínimo 1 punto.\n")
        else:
            bucle_habilidades = False

    except ValueError:
        print("\n  Introduce solo números.\n")

rapunzel = Rapunzel(vida, ataque, defensa, 0)


objetos_habitaciones = {
    "biblioteca": Item("Poción Mágica", "curacion", 8, "Restaura 8 puntos de vida"),
    "cocina": Item("Sartén de Oro", "ataque", 3, "Aumenta el ataque en 3"),
    "jardín": Item("Vendas", "curacion", 5, "Restaura 5 puntos de vida"),
}

guardias_habitaciones = {
    "armería": Guardia("Soldado Real", 8, 3),
    "torre": Guardia("Guardia Mayor", 12, 4),
    "salón": Guardia("Gothel", 18, 6),
}


habitaciones = {
    "celda": {
        "descripción": "La celda donde Rapunzel ha estado encerrada. Hay una puerta entreabierta.",
        "puertas": ["pasillo norte"]
    },
    "pasillo norte": {
        "descripción": "Un pasillo largo y oscuro. Huele a humedad. Hay puertas a ambos lados.",
        "puertas": ["biblioteca", "armería", "pasillo central"]
    },
    "biblioteca": {
        "descripción": "Una sala llena de libros polvorientos. Algo brilla entre los estantes.",
        "puertas": ["pasillo norte"]
    },
    "armería": {
        "descripción": "Una sala con armaduras y armas. No parece estar vacía.",
        "puertas": ["pasillo norte"]
    },
    "pasillo central": {
        "descripción": "El pasillo principal del castillo. Las antorchas iluminan tres direcciones.",
        "puertas": ["cocina", "torre", "pasillo sur"]
    },
    "cocina": {
        "descripción": "Una cocina enorme y abandonada. Hay algo útil por aquí.",
        "puertas": ["pasillo central"]
    },
    "torre": {
        "descripción": "Una torre circular con escaleras de caracol. Alguien monta guardia.",
        "puertas": ["pasillo central"]
    },
    "pasillo sur": {
        "descripción": "Un pasillo que se divide. Una dirección parece no llevar a ninguna parte.",
        "puertas": ["jardín", "sótano", "salón"]
    },
    "jardín": {
        "descripción": "Un jardín interior con plantas marchitas. El silencio es total.",
        "puertas": ["pasillo sur"]
    },
    "sótano": {
        "descripción": "Un callejón sin salida. Solo hay ratas y humedad.",
        "puertas": ["pasillo sur"]
    },
    "salón": {
        "descripción": "El gran salón del castillo. Una figura conocida bloquea la salida.",
        "puertas": ["salida"]
    },
    "salida": {
        "descripción": "La puerta principal del castillo. La libertad está al otro lado.",
        "puertas": []
    },
}

visitadas = []

habitacion_actual = "celda"

total_guardias = 3
guardias_caidos = 0

print("\nRapunzel sale de su celda y comienza la huída.\n")
print("  Escribe el número de la puerta por la que quieres pasar.")
print("  Con (i) consultas el inventario.")
print("  Con (u) usas un objeto.")
print("  Tu objetivo: eliminar a los 3 enemigos del castillo y luego escapar.")
print("  Los enemigos están escondidos en distintas habitaciones.")
print("  Deberás explorar cada rincón del castillo para encontrarlos a todos.")
print("  La salida no desaparecerá pero Gothel seguirá ahí hasta que la derrotes.\n")

mostrar_habitacion(habitacion_actual, habitaciones[habitacion_actual])

bucle_juego = True

while bucle_juego == True:

    accion = input("\n  ¿Qué hace Rapunzel? ").strip()

    if accion == "i":
        rapunzel.mostrar_inventario()
        if len(rapunzel.inventario.objetos) > 0:
            try:
                indice = int(input("  ¿Qué objeto consultas? (número): "))
                objeto = rapunzel.inventario.consultar(indice)
                
                if objeto != "":
                    print("  Has seleccionado este objeto:")
                    objeto.mostrar()
                    
                    confirmar = input("  Eliminar este objeto del inventario? (s/n): ")
                    if confirmar == "s":
                        rapunzel.eliminar_objeto(indice)
            except ValueError:
                print("  Ese número no es válido.")

    elif accion == "u":
        rapunzel.mostrar_inventario()
        if len(rapunzel.inventario.objetos) > 0:
            try:
                indice = int(input("  ¿Qué objeto usas? (número): "))
                rapunzel.utilizar_objeto(indice)
            except ValueError:
                print("  Ese número no es válido.")

    else:
        puertas = habitaciones[habitacion_actual]["puertas"]

        movimiento_valido = False
        try:
            opcion = int(accion)
            if opcion >= 1 and opcion <= len(puertas):
                movimiento_valido = True
        except ValueError:
            movimiento_valido = False

        if movimiento_valido == False:
            print("  Esa opción no es válida.")

        else:
            habitacion_actual = puertas[opcion - 1]

            if habitacion_actual in guardias_habitaciones:
                guardia = guardias_habitaciones[habitacion_actual]
                if guardia.esta_vivo():
                    print(f"\n  Un guardia bloquea el paso: {guardia.nombre}!")
                    rapunzel_viva, eliminado = combate(rapunzel, guardia)

                    if eliminado:
                        guardias_caidos = guardias_caidos + 1
                        restantes = total_guardias - guardias_caidos
                        if restantes > 0:
                            print(f"  [{guardias_caidos}/{total_guardias}] guardias eliminados. Quedan {restantes}.")
                        else:
                            print(f"  [{guardias_caidos}/{total_guardias}] Todos los guardias han caido!")

                    if rapunzel_viva == False:
                        print(f"\nEstado final: Vida {rapunzel.vida} - Ataque {rapunzel.ataque} - Defensa {rapunzel.defensa} - Exp {rapunzel.experiencia}")
                        bucle_juego = False

            if habitacion_actual == "salida":
                print("\n  Rapunzel encuentra la puerta principal y escapa del castillo.")
                print("  Pero el camino a la libertad aún no termina...")
                print(f"\nEstado antes del bosque: Vida {rapunzel.vida} - Ataque {rapunzel.ataque} - Defensa {rapunzel.defensa} - Exp {rapunzel.experiencia}")
                print("")
                bosque_matriz(rapunzel)
                bucle_juego = False

            if bucle_juego == True:
                mostrar_habitacion(habitacion_actual, habitaciones[habitacion_actual])

            if habitacion_actual in objetos_habitaciones and habitacion_actual not in visitadas:
                objeto = objetos_habitaciones[habitacion_actual]
                print(f"\n  Rapunzel encuentra {objeto.nombre}!")
                print(f"  {objeto.descripcion}")
                print(f"  Tipo: {objeto.tipo}  |  Efecto: +{objeto.valor}")
                print(f"  Se ha guardado automaticamente en tu inventario.")
                rapunzel.inventario += objeto
                visitadas.append(habitacion_actual)