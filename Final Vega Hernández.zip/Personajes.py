from Inventario import Inventario

class Rapunzel:
    def __init__(self, vida, ataque, defensa, experiencia):
        self.vida = vida
        self.ataque = ataque
        self.defensa = defensa
        self.experiencia = experiencia
        self.inventario = Inventario()

        print(f"Rapunzel creada con {vida} de vida, {ataque} de ataque, {defensa} de defensa")

    def esta_viva(self):
        viva = False
        if self.vida > 0:
            viva = True
        return viva

    def recibir_golpe(self, golpe):
        golpe_real = golpe - self.defensa

        if golpe_real < 1:
            golpe_real = 1

        self.vida = self.vida - golpe_real

        if self.vida < 0:
            self.vida = 0

        print(f"  Rapunzel recibe {golpe_real} de daño. Vida: {self.vida}")

    def atacar(self, guardia):
        print(f"  Rapunzel ataca a {guardia.nombre} con {self.ataque}")
        guardia.recibir_golpe(self.ataque)

    def utilizar_objeto(self, indice):
        if len(self.inventario.objetos) == 0:
            print("  La mochila está vacía.")
        else:
            if indice < 0:
                print("  Ese objeto no existe en la mochila.")
            else:
                if indice >= len(self.inventario.objetos):
                    print("  Objeto no valido.")
                else:
                    objeto = self.inventario.utilizar(indice)
                    objeto.utilizar(self)

    def eliminar_objeto(self, indice):
        if len(self.inventario.objetos) == 0:
            print("  El inventario esta vacio.")
        else:
            if indice < 0:
                print("  Ese objeto no existe en la mochila.")
            else:
                if indice >= len(self.inventario.objetos):
                    print("  OEse objeto no existe en la mochila.")
                else:
                    self.inventario.eliminar(indice)

    def mostrar_estado(self):
        print(f"  Rapunzel -> Vida: {self.vida}, Ataque: {self.ataque}, Defensa: {self.defensa}, Exp: {self.experiencia}")

    def mostrar_inventario(self):
        self.inventario.mostrar()

    def __lt__(self, otro):
        resultado = False
        if self.vida < otro.vida:
            resultado = True
        return resultado

    def __gt__(self, otro):
        resultado = False
        if self.vida > otro.vida:
            resultado = True
        return resultado


class Guardia:
    def __init__(self, nombre, vida, ataque):
        self.nombre = nombre
        self.vida = vida
        self.ataque = ataque

    def esta_vivo(self):
        vivo = False
        if self.vida > 0:
            vivo = True
        return vivo

    def recibir_golpe(self, golpe):
        self.vida = self.vida - golpe

        if self.vida < 0:
            self.vida = 0

        print(f"  {self.nombre} recibe {golpe} de daño. Vida: {self.vida}")

    def atacar(self, rapunzel):
        print(f"  {self.nombre} ataca a Rapunzel con {self.ataque}")
        rapunzel.recibir_golpe(self.ataque)

    def mostrar_estado(self):
        print(f"  {self.nombre} -> Vida: {self.vida}, Ataque: {self.ataque}")