class Inventario:
    def __init__(self):
        self.objetos = []

    def anadir(self, objeto):
        if self.contiene(objeto):
            print(f"  Ya hay {objeto.nombre} en tu mochila.")
        else:
            self.objetos.append(objeto)
            print(f"  {objeto.nombre} guardado en la mochila.")

    def utilizar(self, indice):
        objeto_seleccionado = "" 
        if indice >= 0 and indice < len(self.objetos):
            objeto_seleccionado = self.objetos[indice]      
            nueva_lista = []                   
            for i in range(len(self.objetos)):
                if not i == indice:                          
                    nueva_lista.append(self.objetos[i])  
            self.objetos = nueva_lista         
        else:
            print("  Objeto no válido.")
        return objeto_seleccionado                      

    def eliminar(self, indice):
        objeto_seleccionado = ""
        if indice >= 0 and indice < len(self.objetos):
            objeto_seleccionado = self.objetos[indice]    
            nueva_lista = []
            for i in range(len(self.objetos)):
                if not i == indice:
                    nueva_lista.append(self.objetos[i])
            self.objetos = nueva_lista
            print(f"  {objeto_seleccionado.nombre} descartado del inventario.")
        else:
            print("  Objeto no válido.")
        return objeto_seleccionado

    def consultar(self, indice):
        objeto_seleccionado = ""
        if indice >= 0 and indice < len(self.objetos):
            objeto_seleccionado = self.objetos[indice]
        else:
            print("  Objeto no valido.")
        return objeto_seleccionado

    def mostrar(self):
        if len(self.objetos) == 0:
            print("  El inventario esta vacio.")
        else:
            print("  Inventario:")
            for i in range(len(self.objetos)):
                print(f"    [{i}]", self.objetos[i])

    def contiene(self, objeto):
        encontrado = False
        for o in self.objetos:
            if o.nombre == objeto.nombre:
                encontrado = True
        else:
            encontrado = encontrado
        return encontrado

    def __iadd__(self, objeto):
        if self.contiene(objeto):
            print(f"  Ya tienes {objeto.nombre} en el inventario.")
        else:
            self.objetos.append(objeto)
            print(f"  {objeto.nombre} guardado en el inventario.")
        return self
   

