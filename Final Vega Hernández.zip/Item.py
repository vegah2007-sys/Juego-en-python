class Item:
    def __init__(self, nombre, tipo, valor, descripcion):
        self.nombre      = nombre
        self.tipo        = tipo
        self.valor       = valor
        self.descripcion = descripcion

    def utilizar(self, rapunzel):
        if self.tipo == "curacion":
            rapunzel.vida += self.valor
            print(f"  Rapunzel ha usado {self.nombre}, gracias a ello ha reestablecido un {self.valor} de vida. Estado actual: {rapunzel.vida}")
        elif self.tipo == "ataque":
            rapunzel.ataque += self.valor
            print(f"  Rapunzel ha usado {self.nombre}, gracias a ello ha ganado +{self.valor} de ataque. Ataque actual: {rapunzel.ataque}")

    def mostrar(self):
        print(f"{self.nombre} ({self.tipo}, valor: {self.valor}) - {self.descripcion}")
